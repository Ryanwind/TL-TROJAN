Public Class NewVersion
  
  Function Main()
    MsgBox("New Version Will Drop S00N")
  End Function
  
End Class
