## BlackWorm v6.0 Black Ninja
#### BlackWorm Developer Stopped Updating The Software
#### This is the Last Version Black.Hacker and DarkSoftwareCo Will Release
#### If You Have Any Issues Please Read The Sourcecode and Try to Solve it

## What's New
##### Good Night njRAT >> Welcome to BlackWorM v6.0 [ Black Ninja ] | Price :- [ Free ]
1. Full Data Transfer Encryption using Base64
2. Modifed Icon Manager
3. Modifed Plugin Manager
4. Modifed Admin Checker
5. Modfied Plugin Invoking
6. Modifed Custom Plugin Invoking
7. DynuDNS Updater
8. NO-IP Automatic Updater
9. New About Page
10. Stable NexTGen WatchDog
11. Add to SchTask
12. Hard Install [ Stealth Mode ]
13. FileZilla Stealer
14. Clean Password Stealer [ Fixes ]
15. CPU,FireWall,Client Privileges,MUTEX Information
16. File Binder
17. Added More then 100 New Custom Icons
18. Modifed Desktop Infection
19. New Port Settings
20. New MUTEX Format (bWorm[xxxxxx-12345])
21. Listview Style
22. Remove Empty Subs and Functions
23. Process Manager With Cusotm Colors
24. Command Shell
25. Remote Powershell
26. Remote Desktop
27. Keylogger Manager
28. Military Grade RSA Encryption With 4096bit Encryption Key for the Host and Port
29. File Manager With a Downloading Large Files and Arabic Names Support [ You Need To Foreword The Port 6060 ]
30. Critical Process
31. Updating Password Plugin
32. Added Produect Serial Stealer
33. Service Manger with Full Service Controller
34. Startup Manager
35. Victim Notification with XtremeRAT Sound
36. IP Tracker [ Removed From Dev-Point Version ]
37. Infect ZIP & RAR Files [ PoC ] [ Beta UnTested ] [ Dev By Black.Hacker using RAR.exe ]
38. Clients Groups [ Single and Multi Manager ]
39. Upgrade Software DotNET Framework From 2.0 to 4.0
34. Small GUI Changes
41. Small Fixes to the Socket to be more stable
42. Multi Transfer
43. Bug Fixes

## License
#### GPL-3.0
#### GNU GENERAL PUBLIC LICENSE

## Copyright
#### This Project is Owned By : DarkSoftwareCo.
#### Copyright © Black.Hacker and DarkSofrwareCo - 2019
